"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useEffect, useState } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { BookMarked, CheckCircle, MessageSquare, Users } from "lucide-react"

export default function MentorDashboard() {
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      try {
        setUser(JSON.parse(userData))
      } catch (error) {
        console.error("Failed to parse user data:", error)
      }
    }
  }, [])

  // Mock data for mentor dashboard
  const stats = {
    assignedLearners: 12,
    pendingReviews: 5,
    coursesManaged: 3,
    unreadMessages: 7,
  }

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8">
      <DashboardHeader
        title={`Welcome back, ${user?.name || "Mentor"}`}
        description="Monitor your learners' progress and review submissions"
      />

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Assigned Learners</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.assignedLearners}</div>
            <p className="text-xs text-muted-foreground">Active learners under your guidance</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Reviews</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pendingReviews}</div>
            <p className="text-xs text-muted-foreground">Submissions awaiting review</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Courses Managed</CardTitle>
            <BookMarked className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.coursesManaged}</div>
            <p className="text-xs text-muted-foreground">Courses you're mentoring</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Unread Messages</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.unreadMessages}</div>
            <p className="text-xs text-muted-foreground">New messages from learners</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent Submissions</CardTitle>
            <CardDescription>Latest submissions from your learners</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">No recent submissions to review.</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Learner Progress</CardTitle>
            <CardDescription>Overview of your learners' progress</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Learner progress data will be displayed here.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
