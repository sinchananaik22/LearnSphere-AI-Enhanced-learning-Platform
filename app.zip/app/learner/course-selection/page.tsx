"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { BookOpen, Clock, Users, CheckCircle } from "lucide-react"

// Available courses for selection
const availableCourses = [
  {
    id: 1,
    title: "React Fundamentals",
    description:
      "Learn the basics of React including components, props, state, and hooks. Perfect for beginners starting their React journey.",
    category: "Frontend",
    instructor: "Sarah Johnson",
    duration: "6 weeks",
    students: 1250,
    moduleCount: 8,
    difficulty: "Beginner" as const,
  },
  {
    id: 2,
    title: "Node.js Backend Development",
    description:
      "Master server-side development with Node.js, Express, and database integration. Build scalable backend applications.",
    category: "Backend",
    instructor: "Mike Chen",
    duration: "8 weeks",
    students: 890,
    moduleCount: 10,
    difficulty: "Intermediate" as const,
  },
  {
    id: 3,
    title: "Database Design & PostgreSQL",
    description:
      "Learn database design principles and master PostgreSQL. Understand relationships, indexing, and query optimization.",
    category: "Database",
    instructor: "Emily Rodriguez",
    duration: "5 weeks",
    students: 675,
    moduleCount: 6,
    difficulty: "Intermediate" as const,
  },
  {
    id: 4,
    title: "Advanced JavaScript Concepts",
    description:
      "Deep dive into advanced JavaScript topics including closures, prototypes, async programming, and design patterns.",
    category: "Frontend",
    instructor: "David Kim",
    duration: "7 weeks",
    students: 1100,
    moduleCount: 12,
    difficulty: "Advanced" as const,
  },
  {
    id: 5,
    title: "RESTful API Design",
    description:
      "Learn to design and build robust RESTful APIs with proper authentication, validation, and documentation.",
    category: "Backend",
    instructor: "Lisa Wang",
    duration: "4 weeks",
    students: 520,
    moduleCount: 8,
    difficulty: "Intermediate" as const,
  },
  {
    id: 6,
    title: "TypeScript for Beginners",
    description: "Get started with TypeScript and learn how to add type safety to your JavaScript applications.",
    category: "Frontend",
    instructor: "Alex Thompson",
    duration: "3 weeks",
    students: 980,
    moduleCount: 5,
    difficulty: "Beginner" as const,
  },
]

export default function CourseSelection() {
  const [selectedCourses, setSelectedCourses] = useState<number[]>([])
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      try {
        setUser(JSON.parse(userData))
      } catch (error) {
        console.error("Failed to parse user data:", error)
        router.push("/login")
      }
    } else {
      router.push("/login")
    }
  }, [router])

  const handleCourseToggle = (courseId: number) => {
    setSelectedCourses((prev) => (prev.includes(courseId) ? prev.filter((id) => id !== courseId) : [...prev, courseId]))
  }

  const handleEnrollment = () => {
    if (selectedCourses.length === 0) {
      alert("Please select at least one course to continue.")
      return
    }

    // Update user with enrolled courses
    const enrolledCourses = availableCourses
      .filter((course) => selectedCourses.includes(course.id))
      .map((course) => ({
        ...course,
        isEnrolled: true,
        progress: 0,
        completedModules: 0,
        enrolledAt: new Date().toISOString(),
      }))

    const updatedUser = {
      ...user,
      enrolledCourses,
    }

    localStorage.setItem("user", JSON.stringify(updatedUser))
    router.push("/learner/dashboard")
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner":
        return "bg-gradient-to-r from-green-100 to-emerald-100 text-green-800 dark:from-green-900 dark:to-emerald-900 dark:text-green-200"
      case "Intermediate":
        return "bg-gradient-to-r from-yellow-100 to-amber-100 text-yellow-800 dark:from-yellow-900 dark:to-amber-900 dark:text-yellow-200"
      case "Advanced":
        return "bg-gradient-to-r from-red-100 to-rose-100 text-red-800 dark:from-red-900 dark:to-rose-900 dark:text-red-200"
      default:
        return "bg-gradient-to-r from-gray-100 to-slate-100 text-gray-800 dark:from-gray-900 dark:to-slate-900 dark:text-gray-200"
    }
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Frontend":
        return "bg-gradient-to-r from-blue-100 to-cyan-100 text-blue-800 dark:from-blue-900 dark:to-cyan-900 dark:text-blue-200"
      case "Backend":
        return "bg-gradient-to-r from-purple-100 to-pink-100 text-purple-800 dark:from-purple-900 dark:to-pink-900 dark:text-purple-200"
      case "Database":
        return "bg-gradient-to-r from-orange-100 to-yellow-100 text-orange-800 dark:from-orange-900 dark:to-yellow-900 dark:text-orange-200"
      default:
        return "bg-gradient-to-r from-gray-100 to-slate-100 text-gray-800 dark:from-gray-900 dark:to-slate-900 dark:text-gray-200"
    }
  }

  if (!user) {
    return (
      <div className="flex-1 space-y-4 p-4 md:p-8">
        <div className="h-8 w-64 bg-muted rounded animate-pulse mb-4" />
        <div className="h-4 w-96 bg-muted rounded animate-pulse mb-8" />
        <div className="h-[600px] bg-muted rounded animate-pulse" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-cyan-50 dark:from-purple-950 dark:via-blue-950 dark:to-cyan-950 p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold">
            <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Welcome to LearnSphere, {user.name}! 🎉
            </span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Choose the courses you'd like to enroll in to start your learning journey. You can always add more courses
            later.
          </p>
        </div>

        <Card className="border-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm shadow-xl">
          <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950">
            <CardTitle className="text-purple-700 dark:text-purple-300 flex items-center gap-2">
              <BookOpen className="h-6 w-6" />
              Select Your Courses
            </CardTitle>
            <CardDescription>
              Choose from our available courses. Selected: {selectedCourses.length} course
              {selectedCourses.length !== 1 ? "s" : ""}
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {availableCourses.map((course) => (
                <Card
                  key={course.id}
                  className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                    selectedCourses.includes(course.id)
                      ? "ring-2 ring-purple-500 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950"
                      : "hover:shadow-md"
                  }`}
                  onClick={() => handleCourseToggle(course.id)}
                >
                  <CardHeader className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <Checkbox
                          checked={selectedCourses.includes(course.id)}
                          onChange={() => handleCourseToggle(course.id)}
                          className="data-[state=checked]:bg-purple-500 data-[state=checked]:border-purple-500"
                        />
                        {selectedCourses.includes(course.id) && <CheckCircle className="h-5 w-5 text-purple-500" />}
                      </div>
                      <div className="flex gap-2">
                        <Badge className={getDifficultyColor(course.difficulty)}>{course.difficulty}</Badge>
                        <Badge className={getCategoryColor(course.category)}>{course.category}</Badge>
                      </div>
                    </div>
                    <CardTitle className="text-lg leading-tight">{course.title}</CardTitle>
                    <CardDescription className="line-clamp-3">{course.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-sm text-muted-foreground">
                      <p className="font-medium">Instructor: {course.instructor}</p>
                    </div>

                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        <span>{course.duration}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        <span>{course.students}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <BookOpen className="h-4 w-4" />
                        <span>{course.moduleCount} modules</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button
                onClick={handleEnrollment}
                disabled={selectedCourses.length === 0}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-8 py-3 text-lg"
              >
                Enroll in {selectedCourses.length} Course{selectedCourses.length !== 1 ? "s" : ""} & Continue
              </Button>
              <Button
                variant="outline"
                onClick={() => router.push("/learner/dashboard")}
                className="border-purple-200 text-purple-700 hover:bg-purple-50 dark:border-purple-700 dark:text-purple-300 dark:hover:bg-purple-900"
              >
                Skip for Now
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
