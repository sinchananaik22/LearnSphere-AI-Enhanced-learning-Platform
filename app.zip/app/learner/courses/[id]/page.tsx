"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, BookOpen, Clock, Users, CheckCircle, Play } from "lucide-react"
import Link from "next/link"

// Mock course data
const mockCourseDetails = {
  1: {
    id: 1,
    title: "React Fundamentals",
    description:
      "Learn the basics of React including components, props, state, and hooks. Perfect for beginners starting their React journey.",
    category: "Frontend",
    instructor: "Sarah Johnson",
    duration: "6 weeks",
    students: 1250,
    moduleCount: 8,
    completedModules: 6,
    progress: 75,
    isEnrolled: true,
    difficulty: "Beginner" as const,
    modules: [
      { id: 1, title: "Introduction to React", duration: "45 min", completed: true },
      { id: 2, title: "Components and JSX", duration: "60 min", completed: true },
      { id: 3, title: "Props and State", duration: "55 min", completed: true },
      { id: 4, title: "Event Handling", duration: "40 min", completed: true },
      { id: 5, title: "React Hooks", duration: "70 min", completed: true },
      { id: 6, title: "Conditional Rendering", duration: "35 min", completed: true },
      { id: 7, title: "Lists and Keys", duration: "50 min", completed: false },
      { id: 8, title: "Final Project", duration: "90 min", completed: false },
    ],
  },
}

export default function CourseDetail() {
  const params = useParams()
  const courseId = Number.parseInt(params.id as string)
  const [course, setCourse] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setCourse(mockCourseDetails[courseId as keyof typeof mockCourseDetails] || null)
      setIsLoading(false)
    }, 500)
  }, [courseId])

  if (isLoading) {
    return (
      <div className="flex-1 space-y-4 p-4 md:p-8">
        <div className="h-8 w-64 bg-muted rounded animate-pulse mb-4" />
        <div className="h-4 w-96 bg-muted rounded animate-pulse mb-8" />
        <div className="h-[600px] bg-muted rounded animate-pulse" />
      </div>
    )
  }

  if (!course) {
    return (
      <div className="flex-1 space-y-4 p-4 md:p-8">
        <DashboardHeader
          title="Course Not Found"
          description="The course you're looking for doesn't exist or you don't have access to it."
        />
        <Button asChild>
          <Link href="/learner/courses">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Courses
          </Link>
        </Button>
      </div>
    )
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "Intermediate":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "Advanced":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
    }
  }

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <div>
          <Button variant="outline" size="sm" asChild className="mb-4">
            <Link href="/learner/courses">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Courses
            </Link>
          </Button>
          <h1 className="text-2xl font-bold">{course.title}</h1>
          <p className="text-muted-foreground">by {course.instructor}</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge className={getDifficultyColor(course.difficulty)}>{course.difficulty}</Badge>
          <Badge variant="outline">{course.category}</Badge>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Course Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">{course.description}</p>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>{course.duration}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span>{course.students} students</span>
                </div>
                <div className="flex items-center gap-2">
                  <BookOpen className="h-4 w-4 text-muted-foreground" />
                  <span>{course.moduleCount} modules</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-muted-foreground" />
                  <span>{course.completedModules} completed</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="modules" className="space-y-4">
            <TabsList>
              <TabsTrigger value="modules">Course Modules</TabsTrigger>
              <TabsTrigger value="assignments">Assignments</TabsTrigger>
              <TabsTrigger value="resources">Resources</TabsTrigger>
            </TabsList>

            <TabsContent value="modules" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Course Modules</CardTitle>
                  <CardDescription>Complete modules in order to progress through the course</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {course.modules.map((module: any, index: number) => (
                    <div
                      key={module.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10">
                          {module.completed ? (
                            <CheckCircle className="h-4 w-4 text-green-600" />
                          ) : (
                            <span className="text-sm font-medium">{index + 1}</span>
                          )}
                        </div>
                        <div>
                          <h4 className="font-medium">{module.title}</h4>
                          <p className="text-sm text-muted-foreground">{module.duration}</p>
                        </div>
                      </div>
                      <Button size="sm" variant={module.completed ? "outline" : "default"}>
                        {module.completed ? "Review" : "Start"}
                        <Play className="ml-2 h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="assignments">
              <Card>
                <CardHeader>
                  <CardTitle>Assignments</CardTitle>
                  <CardDescription>Practice what you've learned with hands-on assignments</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Assignments will be available as you progress through the modules.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="resources">
              <Card>
                <CardHeader>
                  <CardTitle>Additional Resources</CardTitle>
                  <CardDescription>Supplementary materials to enhance your learning</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Resources and reading materials will be provided throughout the course.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Your Progress</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Course Progress</span>
                  <span className="text-sm text-muted-foreground">{course.progress}%</span>
                </div>
                <Progress value={course.progress} className="h-2" />
                <p className="text-xs text-muted-foreground">
                  {course.completedModules} of {course.moduleCount} modules completed
                </p>
              </div>

              {course.isEnrolled ? (
                <Button className="w-full">Continue Learning</Button>
              ) : (
                <Button className="w-full">Enroll in Course</Button>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Instructor</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                  <span className="font-medium text-blue-600 dark:text-blue-400">{course.instructor.charAt(0)}</span>
                </div>
                <div>
                  <p className="font-medium">{course.instructor}</p>
                  <p className="text-sm text-muted-foreground">Course Instructor</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
