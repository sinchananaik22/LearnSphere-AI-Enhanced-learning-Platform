"use client"

import { useState, useEffect } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { Input } from "@/components/ui/input"
import { CourseCard } from "@/components/course-card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// All available courses
const allCourses = [
  {
    id: 1,
    title: "React Fundamentals",
    description:
      "Learn the basics of React including components, props, state, and hooks. Perfect for beginners starting their React journey.",
    category: "Frontend",
    instructor: "Sarah Johnson",
    duration: "6 weeks",
    students: 1250,
    moduleCount: 8,
    difficulty: "Beginner" as const,
  },
  {
    id: 2,
    title: "Node.js Backend Development",
    description:
      "Master server-side development with Node.js, Express, and database integration. Build scalable backend applications.",
    category: "Backend",
    instructor: "Mike Chen",
    duration: "8 weeks",
    students: 890,
    moduleCount: 10,
    difficulty: "Intermediate" as const,
  },
  {
    id: 3,
    title: "Database Design & PostgreSQL",
    description:
      "Learn database design principles and master PostgreSQL. Understand relationships, indexing, and query optimization.",
    category: "Database",
    instructor: "Emily Rodriguez",
    duration: "5 weeks",
    students: 675,
    moduleCount: 6,
    difficulty: "Intermediate" as const,
  },
  {
    id: 4,
    title: "Advanced JavaScript Concepts",
    description:
      "Deep dive into advanced JavaScript topics including closures, prototypes, async programming, and design patterns.",
    category: "Frontend",
    instructor: "David Kim",
    duration: "7 weeks",
    students: 1100,
    moduleCount: 12,
    difficulty: "Advanced" as const,
  },
  {
    id: 5,
    title: "RESTful API Design",
    description:
      "Learn to design and build robust RESTful APIs with proper authentication, validation, and documentation.",
    category: "Backend",
    instructor: "Lisa Wang",
    duration: "4 weeks",
    students: 520,
    moduleCount: 8,
    difficulty: "Intermediate" as const,
  },
  {
    id: 6,
    title: "TypeScript for Beginners",
    description: "Get started with TypeScript and learn how to add type safety to your JavaScript applications.",
    category: "Frontend",
    instructor: "Alex Thompson",
    duration: "3 weeks",
    students: 980,
    moduleCount: 5,
    difficulty: "Beginner" as const,
  },
]

export default function LearnerCourses() {
  const [user, setUser] = useState<any>(null)
  const [courses, setCourses] = useState<any[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Get user from localStorage
    const userData = localStorage.getItem("user")
    if (userData) {
      try {
        const parsedUser = JSON.parse(userData)
        setUser(parsedUser)

        // Map courses with enrollment status
        const enrolledCourseIds = (parsedUser.enrolledCourses || []).map((course: any) => course.id)
        const coursesWithStatus = allCourses.map((course) => {
          const enrolledCourse = (parsedUser.enrolledCourses || []).find((ec: any) => ec.id === course.id)
          return {
            ...course,
            isEnrolled: enrolledCourseIds.includes(course.id),
            progress: enrolledCourse?.progress || 0,
            completedModules: enrolledCourse?.completedModules || 0,
          }
        })

        setCourses(coursesWithStatus)
        setIsLoading(false)
      } catch (error) {
        console.error("Failed to parse user data:", error)
        setIsLoading(false)
      }
    } else {
      setIsLoading(false)
    }
  }, [])

  // Get unique categories
  const categories = ["all", ...new Set(courses.map((course) => course.category))]

  // Filter courses based on search query and category
  const filteredCourses = courses.filter((course) => {
    const matchesSearch =
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.instructor.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = categoryFilter === "all" || course.category === categoryFilter
    return matchesSearch && matchesCategory
  })

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8">
      <DashboardHeader
        title="📚 Available Courses"
        description="Browse and enroll in courses to continue your learning journey"
      />

      <div className="flex flex-col sm:flex-row gap-4">
        <Input
          placeholder="Search courses..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="sm:max-w-xs border-purple-200 dark:border-purple-700 focus:border-purple-400 dark:focus:border-purple-500"
        />
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="sm:max-w-xs border-blue-200 dark:border-blue-700">
            <SelectValue placeholder="Filter by category" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((category) => (
              <SelectItem key={category} value={category}>
                {category === "all" ? "All Categories" : category}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-[400px] rounded-lg bg-muted animate-pulse" />
          ))}
        </div>
      ) : filteredCourses.length > 0 ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filteredCourses.map((course) => (
            <CourseCard key={course.id} course={course} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center h-[400px] text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full flex items-center justify-center mb-4">
            <span className="text-2xl">📚</span>
          </div>
          <h3 className="text-2xl font-semibold mb-2">No courses found</h3>
          <p className="text-muted-foreground">Try adjusting your search or filter to find what you're looking for.</p>
        </div>
      )}
    </div>
  )
}
