"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { BookMarked, CheckCircle, Clock, FileText, Plus } from "lucide-react"
import { DashboardHeader } from "@/components/dashboard-header"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function LearnerDashboard() {
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    // Get user from localStorage
    const userData = localStorage.getItem("user")
    if (userData) {
      try {
        setUser(JSON.parse(userData))
      } catch (error) {
        console.error("Failed to parse user data:", error)
      }
    }
  }, [])

  if (!user) {
    return (
      <div className="flex-1 space-y-4 p-4 md:p-8">
        <div className="h-8 w-64 bg-slate-200 dark:bg-slate-700 rounded animate-pulse mb-4" />
        <div className="h-4 w-96 bg-slate-200 dark:bg-slate-700 rounded animate-pulse mb-8" />
        <div className="h-[600px] bg-slate-200 dark:bg-slate-700 rounded animate-pulse" />
      </div>
    )
  }

  const enrolledCourses = user.enrolledCourses || []
  const userSubmissions = user.submissions || []
  const totalModules = enrolledCourses.reduce((acc: number, course: any) => acc + course.moduleCount, 0)
  const completedModules = enrolledCourses.reduce((acc: number, course: any) => acc + (course.completedModules || 0), 0)
  const overallProgress = totalModules > 0 ? Math.round((completedModules / totalModules) * 100) : 0

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8">
      <DashboardHeader
        title={`Welcome back, ${user.name}! 👋`}
        description="Track your learning progress and recent activities"
      />

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-l-4 border-l-blue-600">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-700 dark:text-slate-300">Enrolled Courses</CardTitle>
            <BookMarked className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-800 dark:text-slate-200">{enrolledCourses.length}</div>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              {enrolledCourses.length > 0 ? `${enrolledCourses.length} active courses` : "No enrolled courses"}
            </p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-emerald-600">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-700 dark:text-slate-300">Overall Progress</CardTitle>
            <CheckCircle className="h-4 w-4 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-800 dark:text-slate-200">{overallProgress}%</div>
            <Progress value={overallProgress} className="h-2 mt-2" />
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-amber-600">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-700 dark:text-slate-300">Submissions</CardTitle>
            <FileText className="h-4 w-4 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-800 dark:text-slate-200">{userSubmissions.length}</div>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              {userSubmissions.length > 0
                ? `${userSubmissions.filter((s: any) => s.status === "pending").length} pending review`
                : "No submissions yet"}
            </p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-slate-600">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-700 dark:text-slate-300">Study Time</CardTitle>
            <Clock className="h-4 w-4 text-slate-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-800 dark:text-slate-200">{user.totalHours || 0}h</div>
            <p className="text-xs text-slate-600 dark:text-slate-400">Total learning hours</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-slate-200 dark:border-slate-700">
          <CardHeader>
            <CardTitle className="text-slate-800 dark:text-slate-200">Your Courses</CardTitle>
            <CardDescription className="text-slate-600 dark:text-slate-400">
              Your enrolled courses and progress
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            {enrolledCourses.length > 0 ? (
              enrolledCourses.map((course: any) => (
                <div key={course.id} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <h4 className="font-medium text-slate-800 dark:text-slate-200">{course.title}</h4>
                    <span className="text-sm text-slate-600 dark:text-slate-400">{course.progress || 0}%</span>
                  </div>
                  <Progress value={course.progress || 0} className="h-2" />
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    {course.completedModules || 0} of {course.moduleCount} modules completed
                  </p>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <BookMarked className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-800 dark:text-slate-200 mb-2">No courses enrolled</h3>
                <p className="text-slate-600 dark:text-slate-400 mb-4">
                  Start your learning journey by enrolling in courses
                </p>
                <Button asChild className="bg-blue-600 hover:bg-blue-700 text-white">
                  <Link href="/learner/course-selection">
                    <Plus className="mr-2 h-4 w-4" />
                    Browse Courses
                  </Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-slate-200 dark:border-slate-700">
          <CardHeader>
            <CardTitle className="text-slate-800 dark:text-slate-200">Recent Submissions</CardTitle>
            <CardDescription className="text-slate-600 dark:text-slate-400">
              Your latest assignment submissions
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            {userSubmissions.length > 0 ? (
              userSubmissions.slice(0, 3).map((submission: any) => (
                <div
                  key={submission.id}
                  className="flex justify-between items-center p-3 border border-slate-200 dark:border-slate-700 rounded-lg"
                >
                  <div>
                    <h4 className="font-medium text-slate-800 dark:text-slate-200">{submission.title}</h4>
                    <p className="text-sm text-slate-600 dark:text-slate-400">{submission.course}</p>
                  </div>
                  <span
                    className={`px-2 py-1 rounded-full text-xs ${
                      submission.status === "approved"
                        ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200"
                        : submission.status === "pending"
                          ? "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200"
                          : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
                    }`}
                  >
                    {submission.status}
                  </span>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <FileText className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-800 dark:text-slate-200 mb-2">No submissions yet</h3>
                <p className="text-slate-600 dark:text-slate-400">Complete assignments to see your submissions here</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
