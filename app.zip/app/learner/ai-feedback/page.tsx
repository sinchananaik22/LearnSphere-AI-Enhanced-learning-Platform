"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Brain, Sparkles, TrendingUp, Target, Lightbulb, CheckCircle, Info } from "lucide-react"

// Mock AI feedback data
const mockFeedback = [
  {
    id: 1,
    type: "code_review",
    title: "React Component Analysis",
    content:
      "Your React component demonstrates good understanding of functional components and hooks. However, consider using useCallback for event handlers to optimize performance.",
    score: 85,
    suggestions: [
      "Implement useCallback for event handlers",
      "Add PropTypes for better type checking",
      "Consider memoizing expensive calculations",
    ],
    strengths: ["Clean component structure", "Proper use of useState hook", "Good naming conventions"],
    timestamp: "2024-01-20T10:30:00Z",
    category: "Performance",
  },
  {
    id: 2,
    type: "assignment_feedback",
    title: "Database Design Assessment",
    content:
      "Your database schema shows solid understanding of normalization principles. The relationships are well-defined, but consider adding more indexes for query optimization.",
    score: 92,
    suggestions: [
      "Add composite indexes for frequently queried columns",
      "Consider partitioning for large tables",
      "Implement database constraints for data integrity",
    ],
    strengths: ["Excellent normalization", "Clear relationship definitions", "Proper primary key selection"],
    timestamp: "2024-01-18T14:20:00Z",
    category: "Database Design",
  },
  {
    id: 3,
    type: "learning_path",
    title: "JavaScript Fundamentals Progress",
    content:
      "You've made excellent progress in JavaScript fundamentals. Your understanding of closures and scope has improved significantly. Focus on asynchronous programming next.",
    score: 78,
    suggestions: [
      "Practice with Promises and async/await",
      "Learn about event loop mechanics",
      "Explore error handling patterns",
    ],
    strengths: ["Strong grasp of closures", "Good understanding of scope", "Consistent coding style"],
    timestamp: "2024-01-15T09:45:00Z",
    category: "Fundamentals",
  },
]

export default function AIFeedback() {
  const [feedback, setFeedback] = useState(mockFeedback)
  const [newCode, setNewCode] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  const handleAnalyzeCode = async () => {
    if (!newCode.trim()) return

    setIsAnalyzing(true)

    // Simulate AI analysis
    setTimeout(() => {
      const newFeedbackItem = {
        id: feedback.length + 1,
        type: "code_review",
        title: "Code Analysis Result",
        content:
          "Your code shows good structure and logic. Consider adding error handling and optimizing the algorithm for better performance.",
        score: Math.floor(Math.random() * 30) + 70, // Random score between 70-100
        suggestions: [
          "Add try-catch blocks for error handling",
          "Consider using more efficient algorithms",
          "Add input validation",
        ],
        strengths: ["Clean code structure", "Good variable naming", "Logical flow"],
        timestamp: new Date().toISOString(),
        category: "Code Review",
      }

      setFeedback([newFeedbackItem, ...feedback])
      setNewCode("")
      setIsAnalyzing(false)
    }, 2000)
  }

  const getScoreColor = (score: number) => {
    if (score >= 90) return "from-green-500 to-emerald-500"
    if (score >= 80) return "from-blue-500 to-cyan-500"
    if (score >= 70) return "from-yellow-500 to-amber-500"
    return "from-red-500 to-rose-500"
  }

  const getCategoryColor = (category: string) => {
    switch (category.toLowerCase()) {
      case "performance":
        return "bg-gradient-to-r from-purple-100 to-pink-100 text-purple-800 dark:from-purple-900 dark:to-pink-900 dark:text-purple-200"
      case "database design":
        return "bg-gradient-to-r from-blue-100 to-cyan-100 text-blue-800 dark:from-blue-900 dark:to-cyan-900 dark:text-blue-200"
      case "fundamentals":
        return "bg-gradient-to-r from-green-100 to-emerald-100 text-green-800 dark:from-green-900 dark:to-emerald-900 dark:text-green-200"
      case "code review":
        return "bg-gradient-to-r from-orange-100 to-yellow-100 text-orange-800 dark:from-orange-900 dark:to-yellow-900 dark:text-orange-200"
      default:
        return "bg-gradient-to-r from-gray-100 to-slate-100 text-gray-800 dark:from-gray-900 dark:to-slate-900 dark:text-gray-200"
    }
  }

  const averageScore = Math.round(feedback.reduce((acc, item) => acc + item.score, 0) / feedback.length)

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8">
      <DashboardHeader
        title="🤖 AI Feedback & Analysis"
        description="Get intelligent feedback on your code and learning progress"
      />

      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-l-4 border-l-purple-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950">
            <CardTitle className="text-sm font-medium text-purple-700 dark:text-purple-300">Total Feedback</CardTitle>
            <Brain className="h-4 w-4 text-purple-600 dark:text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-700 dark:text-purple-300">{feedback.length}</div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-950 dark:to-cyan-950">
            <CardTitle className="text-sm font-medium text-blue-700 dark:text-blue-300">Average Score</CardTitle>
            <Target className="h-4 w-4 text-blue-600 dark:text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-700 dark:text-blue-300">{averageScore}%</div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950">
            <CardTitle className="text-sm font-medium text-green-700 dark:text-green-300">Improvements</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600 dark:text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-700 dark:text-green-300">+12%</div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-orange-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 bg-gradient-to-r from-orange-50 to-yellow-50 dark:from-orange-950 dark:to-yellow-950">
            <CardTitle className="text-sm font-medium text-orange-700 dark:text-orange-300">Suggestions</CardTitle>
            <Lightbulb className="h-4 w-4 text-orange-600 dark:text-orange-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-700 dark:text-orange-300">
              {feedback.reduce((acc, item) => acc + item.suggestions.length, 0)}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="feedback" className="space-y-4">
        <TabsList className="bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900 dark:to-pink-900">
          <TabsTrigger
            value="feedback"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-pink-500 data-[state=active]:text-white"
          >
            Recent Feedback
          </TabsTrigger>
          <TabsTrigger
            value="analyze"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-cyan-500 data-[state=active]:text-white"
          >
            Analyze Code
          </TabsTrigger>
        </TabsList>

        <TabsContent value="feedback" className="space-y-4">
          {feedback.map((item) => (
            <Card key={item.id} className="hover:shadow-lg transition-all duration-200 border-l-4 border-l-indigo-500">
              <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950">
                <div className="flex justify-between items-start">
                  <div className="space-y-2">
                    <CardTitle className="text-indigo-700 dark:text-indigo-300 flex items-center gap-2">
                      <Brain className="h-5 w-5" />
                      {item.title}
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <Badge className={getCategoryColor(item.category)}>{item.category}</Badge>
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        {new Date(item.timestamp).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-sm font-medium">Score:</span>
                      <Badge className={`bg-gradient-to-r ${getScoreColor(item.score)} text-white`}>
                        {item.score}%
                      </Badge>
                    </div>
                    <Progress value={item.score} className="w-20 h-2" />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-4 space-y-4">
                <div className="bg-gradient-to-r from-gray-50 to-blue-50 dark:from-gray-800 dark:to-blue-900 p-4 rounded-lg">
                  <p className="text-gray-700 dark:text-gray-300">{item.content}</p>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-medium text-green-700 dark:text-green-300 flex items-center gap-2">
                      <CheckCircle className="h-4 w-4" />
                      Strengths
                    </h4>
                    <ul className="space-y-1">
                      {item.strengths.map((strength, index) => (
                        <li key={index} className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-2">
                          <div className="w-2 h-2 bg-gradient-to-r from-green-400 to-emerald-400 rounded-full" />
                          {strength}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-medium text-orange-700 dark:text-orange-300 flex items-center gap-2">
                      <Lightbulb className="h-4 w-4" />
                      Suggestions
                    </h4>
                    <ul className="space-y-1">
                      {item.suggestions.map((suggestion, index) => (
                        <li key={index} className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-2">
                          <div className="w-2 h-2 bg-gradient-to-r from-orange-400 to-yellow-400 rounded-full" />
                          {suggestion}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="analyze" className="space-y-4">
          <Card className="border-l-4 border-l-blue-500">
            <CardHeader className="bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-950 dark:to-cyan-950">
              <CardTitle className="text-blue-700 dark:text-blue-300 flex items-center gap-2">
                <Sparkles className="h-5 w-5" />
                AI Code Analysis
              </CardTitle>
              <CardDescription>
                Paste your code below and get instant AI-powered feedback and suggestions
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-4 space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Your Code</label>
                <Textarea
                  placeholder="Paste your code here for AI analysis..."
                  value={newCode}
                  onChange={(e) => setNewCode(e.target.value)}
                  rows={10}
                  className="font-mono border-blue-200 dark:border-blue-700 focus:border-blue-400 dark:focus:border-blue-500"
                />
              </div>

              <div className="flex items-center gap-2 p-3 bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-900 dark:to-cyan-900 rounded-lg">
                <Info className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  Our AI will analyze your code for performance, best practices, and potential improvements.
                </p>
              </div>

              <Button
                onClick={handleAnalyzeCode}
                disabled={!newCode.trim() || isAnalyzing}
                className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600"
              >
                {isAnalyzing ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Brain className="mr-2 h-4 w-4" />
                    Analyze Code
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
