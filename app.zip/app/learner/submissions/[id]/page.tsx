"use client"

import { useState } from "react"
import { useParams } from "next/navigation"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Clock, FileText, MessageSquare } from "lucide-react"
import Link from "next/link"
import { useSubmission } from "@/hooks/use-submission"
import { AIFeedback } from "@/components/ai-feedback"
import { MentorFeedback } from "@/components/mentor-feedback"

export default function SubmissionDetail() {
  const params = useParams()
  const submissionId = params.id as string
  const { submission, isLoading } = useSubmission(submissionId)
  const [activeTab, setActiveTab] = useState("submission")

  if (isLoading) {
    return (
      <div className="flex-1 space-y-4 p-4 md:p-8">
        <div className="h-8 w-64 bg-muted rounded animate-pulse mb-4" />
        <div className="h-4 w-96 bg-muted rounded animate-pulse mb-8" />
        <div className="h-[600px] bg-muted rounded animate-pulse" />
      </div>
    )
  }

  if (!submission) {
    return (
      <div className="flex-1 space-y-4 p-4 md:p-8">
        <DashboardHeader
          title="Submission Not Found"
          description="The submission you're looking for doesn't exist or you don't have permission to view it."
        />
        <Button asChild>
          <Link href="/learner/submissions">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Submissions
          </Link>
        </Button>
      </div>
    )
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-green-500 text-white"
      case "rejected":
        return "bg-red-500 text-white"
      case "pending":
        return "bg-yellow-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <div>
          <Button variant="outline" size="sm" asChild className="mb-4">
            <Link href="/learner/submissions">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Submissions
            </Link>
          </Button>
          <h1 className="text-2xl font-bold">{submission.title}</h1>
          <p className="text-muted-foreground">
            Submitted for {submission.courseName} - {submission.moduleName}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge className={getStatusColor(submission.status)}>
            {submission.status.charAt(0).toUpperCase() + submission.status.slice(1)}
          </Badge>
          <div className="text-sm text-muted-foreground flex items-center">
            <Clock className="h-4 w-4 mr-1" />
            {new Date(submission.submittedAt).toLocaleDateString()}
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="submission">
            <FileText className="h-4 w-4 mr-2" />
            Submission
          </TabsTrigger>
          <TabsTrigger value="ai-feedback">
            <MessageSquare className="h-4 w-4 mr-2" />
            AI Feedback
          </TabsTrigger>
          <TabsTrigger value="mentor-feedback">
            <MessageSquare className="h-4 w-4 mr-2" />
            Mentor Feedback
          </TabsTrigger>
        </TabsList>

        <TabsContent value="submission" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Your Submission</CardTitle>
              <CardDescription>Your submitted work for review</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="prose dark:prose-invert max-w-none">
                <div dangerouslySetInnerHTML={{ __html: submission.content }} />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai-feedback">
          <AIFeedback feedback={submission.aiFeedback} />
        </TabsContent>

        <TabsContent value="mentor-feedback">
          <MentorFeedback feedback={submission.mentorFeedback} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
