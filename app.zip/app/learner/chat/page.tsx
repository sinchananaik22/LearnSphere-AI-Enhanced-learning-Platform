"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Send, MessageCircle, Users } from "lucide-react"

// Mock mentors data
const mockMentors = [
  {
    id: 1,
    name: "Sarah Johnson",
    avatar: "/placeholder.svg",
    status: "online",
    unread: 2,
    lastMessage: "Great progress on your React project!",
    specialty: "Frontend Development",
  },
  {
    id: 2,
    name: "Mike Chen",
    avatar: "/placeholder.svg",
    status: "offline",
    unread: 0,
    lastMessage: "Let's review your Node.js code tomorrow",
    specialty: "Backend Development",
  },
  {
    id: 3,
    name: "Emily Rodriguez",
    avatar: "/placeholder.svg",
    status: "online",
    unread: 1,
    lastMessage: "Your database design looks solid",
    specialty: "Database Design",
  },
]

// Mock messages
const mockMessages = [
  {
    id: 1,
    sender: "mentor",
    content: "Hi! How's your React project coming along?",
    timestamp: new Date(Date.now() - 3600000),
    senderName: "Sarah Johnson",
  },
  {
    id: 2,
    sender: "user",
    content: "It's going well! I've completed the component structure and working on state management now.",
    timestamp: new Date(Date.now() - 3500000),
    senderName: "You",
  },
  {
    id: 3,
    sender: "mentor",
    content: "Excellent! Remember to use useCallback for your event handlers to optimize performance.",
    timestamp: new Date(Date.now() - 3400000),
    senderName: "Sarah Johnson",
  },
  {
    id: 4,
    sender: "user",
    content: "Thanks for the tip! I'll implement that right away.",
    timestamp: new Date(Date.now() - 3300000),
    senderName: "You",
  },
]

export default function LearnerChat() {
  const [mentors, setMentors] = useState(mockMentors)
  const [activeChat, setActiveChat] = useState(mockMentors[0])
  const [messages, setMessages] = useState(mockMessages)
  const [newMessage, setNewMessage] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (newMessage.trim() && activeChat) {
      const message = {
        id: messages.length + 1,
        sender: "user" as const,
        content: newMessage,
        timestamp: new Date(),
        senderName: "You",
      }
      setMessages([...messages, message])
      setNewMessage("")
    }
  }

  const selectChat = (mentorId: number) => {
    const mentor = mentors.find((m) => m.id === mentorId)
    if (mentor) {
      setActiveChat(mentor)
      // Mark messages as read
      setMentors(mentors.map((m) => (m.id === mentorId ? { ...m, unread: 0 } : m)))
    }
  }

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8">
      <DashboardHeader title="💬 Chat with Mentors" description="Get real-time assistance from your assigned mentors" />

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 h-[calc(100vh-220px)]">
        <Card className="md:col-span-1 overflow-hidden border-l-4 border-l-purple-500">
          <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950">
            <CardTitle className="flex items-center gap-2 text-purple-700 dark:text-purple-300">
              <Users className="h-5 w-5" />
              Your Mentors
            </CardTitle>
            <CardDescription>Connect with your assigned mentors</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[calc(100vh-350px)]">
              <div className="px-4 py-2">
                {mentors.map((mentor) => (
                  <div
                    key={mentor.id}
                    className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer mb-2 transition-all duration-200 ${
                      activeChat?.id === mentor.id
                        ? "bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900 dark:to-pink-900 shadow-md"
                        : "hover:bg-gradient-to-r hover:from-gray-50 hover:to-gray-100 dark:hover:from-gray-800 dark:hover:to-gray-700"
                    }`}
                    onClick={() => selectChat(mentor.id)}
                  >
                    <div className="relative">
                      <Avatar className="border-2 border-purple-200 dark:border-purple-700">
                        <AvatarImage src={mentor.avatar || "/placeholder.svg"} />
                        <AvatarFallback className="bg-gradient-to-br from-purple-400 to-pink-400 text-white">
                          {mentor.name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div
                        className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${
                          mentor.status === "online" ? "bg-green-500" : "bg-gray-400"
                        }`}
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate text-gray-900 dark:text-gray-100">{mentor.name}</p>
                      <p className="text-xs text-purple-600 dark:text-purple-400 truncate">{mentor.specialty}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{mentor.lastMessage}</p>
                    </div>
                    {mentor.unread > 0 && (
                      <Badge className="bg-gradient-to-r from-red-500 to-pink-500 text-white text-xs">
                        {mentor.unread}
                      </Badge>
                    )}
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        <Card className="md:col-span-3 flex flex-col border-l-4 border-l-blue-500">
          {activeChat ? (
            <>
              <CardHeader className="border-b px-4 py-3 bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-950 dark:to-cyan-950">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Avatar className="border-2 border-blue-200 dark:border-blue-700">
                      <AvatarImage src={activeChat.avatar || "/placeholder.svg"} />
                      <AvatarFallback className="bg-gradient-to-br from-blue-400 to-cyan-400 text-white">
                        {activeChat.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div
                      className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${
                        activeChat.status === "online" ? "bg-green-500" : "bg-gray-400"
                      }`}
                    />
                  </div>
                  <div>
                    <CardTitle className="text-base text-blue-700 dark:text-blue-300">{activeChat.name}</CardTitle>
                    <CardDescription className="text-xs flex items-center gap-1">
                      <span
                        className={`w-2 h-2 rounded-full ${
                          activeChat.status === "online" ? "bg-green-500" : "bg-gray-400"
                        }`}
                      />
                      {activeChat.status === "online" ? "Online" : "Last seen recently"} • {activeChat.specialty}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <ScrollArea className="flex-1 p-4">
                <div className="space-y-4">
                  {messages.map((message, index) => (
                    <div key={index} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
                      <div className="flex items-start gap-2 max-w-[80%]">
                        {message.sender === "mentor" && (
                          <Avatar className="w-8 h-8 border border-purple-200 dark:border-purple-700">
                            <AvatarImage src={activeChat.avatar || "/placeholder.svg"} />
                            <AvatarFallback className="bg-gradient-to-br from-purple-400 to-pink-400 text-white text-xs">
                              {activeChat.name.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                        )}
                        <div
                          className={`rounded-2xl px-4 py-2 shadow-sm ${
                            message.sender === "user"
                              ? "bg-gradient-to-r from-blue-500 to-cyan-500 text-white"
                              : "bg-gradient-to-r from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-600 text-gray-900 dark:text-gray-100"
                          }`}
                        >
                          <p className="text-sm">{message.content}</p>
                          <p
                            className={`text-xs mt-1 ${
                              message.sender === "user" ? "text-blue-100" : "text-gray-500 dark:text-gray-400"
                            }`}
                          >
                            {new Date(message.timestamp).toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </p>
                        </div>
                        {message.sender === "user" && (
                          <Avatar className="w-8 h-8 border border-blue-200 dark:border-blue-700">
                            <AvatarFallback className="bg-gradient-to-br from-blue-400 to-cyan-400 text-white text-xs">
                              U
                            </AvatarFallback>
                          </Avatar>
                        )}
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>
              <CardFooter className="border-t p-3 bg-gradient-to-r from-gray-50 to-blue-50 dark:from-gray-800 dark:to-blue-900">
                <form onSubmit={handleSendMessage} className="flex w-full gap-2">
                  <Input
                    placeholder="Type your message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    className="flex-1 border-blue-200 dark:border-blue-700 focus:border-blue-400 dark:focus:border-blue-500"
                  />
                  <Button
                    type="submit"
                    size="icon"
                    className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </form>
              </CardFooter>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center p-4">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full flex items-center justify-center mb-4">
                <MessageCircle className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-900 dark:text-gray-100">
                Select a mentor to start chatting
              </h3>
              <p className="text-gray-600 dark:text-gray-400 max-w-md">
                Choose a mentor from the list to get help with your courses and assignments.
              </p>
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}
