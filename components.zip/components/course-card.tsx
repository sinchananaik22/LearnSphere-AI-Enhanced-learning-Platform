import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Clock, Users } from "lucide-react"
import Link from "next/link"

interface Course {
  id: number
  title: string
  description: string
  category: string
  instructor: string
  duration: string
  students: number
  progress?: number
  moduleCount: number
  completedModules?: number
  isEnrolled?: boolean
  difficulty: "Beginner" | "Intermediate" | "Advanced"
}

interface CourseCardProps {
  course: Course
}

export function CourseCard({ course }: CourseCardProps) {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "Intermediate":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "Advanced":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
    }
  }

  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <div className="flex justify-between items-start mb-2">
          <Badge className={getDifficultyColor(course.difficulty)}>{course.difficulty}</Badge>
          <Badge variant="outline">{course.category}</Badge>
        </div>
        <CardTitle className="line-clamp-2">{course.title}</CardTitle>
        <CardDescription className="line-clamp-3">{course.description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col justify-between">
        <div className="space-y-4">
          <div className="text-sm text-muted-foreground">
            <p>Instructor: {course.instructor}</p>
          </div>

          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              <span>{course.duration}</span>
            </div>
            <div className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              <span>{course.students} students</span>
            </div>
            <div className="flex items-center gap-1">
              <BookOpen className="h-4 w-4" />
              <span>{course.moduleCount} modules</span>
            </div>
          </div>

          {course.isEnrolled && course.progress !== undefined && (
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Progress</span>
                <span className="text-sm text-muted-foreground">{course.progress}%</span>
              </div>
              <Progress value={course.progress} className="h-2" />
              <p className="text-xs text-muted-foreground">
                {course.completedModules || 0} of {course.moduleCount} modules completed
              </p>
            </div>
          )}
        </div>

        <div className="mt-4">
          {course.isEnrolled ? (
            <Button asChild className="w-full">
              <Link href={`/learner/courses/${course.id}`}>Continue Learning</Link>
            </Button>
          ) : (
            <Button asChild className="w-full">
              <Link href={`/learner/courses/${course.id}`}>Enroll Now</Link>
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
