"use client"

import { usePathname } from "next/navigation"
import Link from "next/link"
import { useEffect, useState } from "react"
import {
  BookOpen,
  LayoutDashboard,
  BookMarked,
  MessageSquare,
  Users,
  Settings,
  LogOut,
  User,
  FileText,
  Brain,
  BarChart3,
} from "lucide-react"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"

export function AppSidebar() {
  const pathname = usePathname()
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    // Get user from localStorage
    const userData = localStorage.getItem("user")
    if (userData) {
      try {
        setUser(JSON.parse(userData))
      } catch (error) {
        console.error("Failed to parse user data:", error)
      }
    }
  }, [])

  const logout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("user")
    window.location.href = "/"
  }

  // Determine which menu items to show based on user role
  const isAdmin = user?.role === "admin"
  const isMentor = user?.role === "mentor"
  const isLearner = user?.role === "learner"

  // Base path for role-specific routes
  const basePath = isAdmin ? "/admin" : isMentor ? "/mentor" : "/learner"

  // Common menu items for all roles
  const commonMenuItems = [
    {
      title: "Dashboard",
      icon: LayoutDashboard,
      href: `${basePath}/dashboard`,
    },
    {
      title: "Profile",
      icon: User,
      href: `${basePath}/profile`,
    },
  ]

  // Role-specific menu items
  const adminMenuItems = [
    {
      title: "Users",
      icon: Users,
      href: "/admin/users",
    },
    {
      title: "Courses",
      icon: BookMarked,
      href: "/admin/courses",
    },
    {
      title: "Reports",
      icon: BarChart3,
      href: "/admin/reports",
    },
    {
      title: "Settings",
      icon: Settings,
      href: "/admin/settings",
    },
  ]

  const mentorMenuItems = [
    {
      title: "Learners",
      icon: Users,
      href: "/mentor/learners",
    },
    {
      title: "Courses",
      icon: BookMarked,
      href: "/mentor/courses",
    },
    {
      title: "Submissions",
      icon: FileText,
      href: "/mentor/submissions",
    },
    {
      title: "Chat",
      icon: MessageSquare,
      href: "/mentor/chat",
    },
  ]

  const learnerMenuItems = [
    {
      title: "Courses",
      icon: BookMarked,
      href: "/learner/courses",
    },
    {
      title: "Submissions",
      icon: FileText,
      href: "/learner/submissions",
    },
    {
      title: "AI Feedback",
      icon: Brain,
      href: "/learner/ai-feedback",
    },
    {
      title: "Chat",
      icon: MessageSquare,
      href: "/learner/chat",
    },
  ]

  // Determine which menu items to show
  let menuItems = [...commonMenuItems]

  if (isAdmin) {
    menuItems = [...menuItems, ...adminMenuItems]
  } else if (isMentor) {
    menuItems = [...menuItems, ...mentorMenuItems]
  } else if (isLearner) {
    menuItems = [...menuItems, ...learnerMenuItems]
  }

  // If no user is logged in, don't show the sidebar
  if (!user) {
    return null
  }

  return (
    <Sidebar className="border-r border-slate-200 dark:border-slate-700">
      <SidebarHeader className="flex flex-col gap-2 px-4 py-2 border-b border-slate-200 dark:border-slate-700">
        <div className="flex items-center gap-2 px-2">
          <div className="w-6 h-6 bg-blue-600 rounded flex items-center justify-center">
            <BookOpen className="h-4 w-4 text-white" />
          </div>
          <span className="text-lg font-bold text-slate-800 dark:text-slate-200">LearnSphere</span>
        </div>
      </SidebarHeader>
      <SidebarSeparator />
      <SidebarContent>
        <SidebarMenu>
          {menuItems.map((item) => (
            <SidebarMenuItem key={item.title}>
              <SidebarMenuButton asChild isActive={pathname === item.href} tooltip={item.title}>
                <Link
                  href={item.href}
                  className="text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400"
                >
                  <item.icon className="h-4 w-4" />
                  <span>{item.title}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="p-4 border-t border-slate-200 dark:border-slate-700">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center">
              <span className="font-medium text-sm text-white">{user?.name?.charAt(0)?.toUpperCase() || "U"}</span>
            </div>
            <div className="text-sm">
              <p className="font-medium text-slate-800 dark:text-slate-200">{user?.name || "User"}</p>
              <p className="text-xs text-slate-600 dark:text-slate-400 capitalize">{user?.role || "User"}</p>
            </div>
          </div>
        </div>
        <Button
          variant="outline"
          className="w-full justify-start border-slate-300 text-slate-700 hover:bg-slate-50 dark:border-slate-600 dark:text-slate-300 dark:hover:bg-slate-800"
          onClick={logout}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Logout
        </Button>
      </SidebarFooter>
    </Sidebar>
  )
}
